﻿namespace eimprovement.WebApplication.Models
{
    public class Tag
    {
        public long id { get; set; }
        public string name { get; set; }
    }
}